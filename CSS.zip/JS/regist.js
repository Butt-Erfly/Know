document.querySelector('#signup').onclick = function(event){
    event.preventDefault();
    console.log('work')
}